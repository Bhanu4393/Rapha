https://drive.google.com/file/d/1gw82rrExyQ7dMAIFLA5zgRG_4WIEKQoJ/view?usp=drivesdk
https://docs.google.com/presentation/d/12F_hhcC2B-vdlYdwdqF4nCNWP8liHkPY/edit?usp=drivesdk&ouid=116613340743532082590&rtpof=true&sd=true
